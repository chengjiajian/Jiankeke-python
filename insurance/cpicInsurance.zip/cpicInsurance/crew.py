import requests
import time
import re
import datetime
import json
from pymongo import MongoClient

conn = MongoClient('140.143.238.224', 27017)
conn['cookieDB'].authenticate('root','cjj941208',mechanism='SCRAM-SHA-1')
db = conn.cookieDB
cookiesTable = db.cookiesTable
CpicInput=db.CpicInput
carData = db.carData
responseData = db.responseData

for i in cookiesTable.find({'company_id': 2}):
    cookie = i['cookie_value']
print(cookie)
for data in CpicInput.find():
    data.pop('_id')
    headers = {'Accept':'application/json, text/javascript, */*; q=0.01',
'Content-Type':'application/json;charset=UTF-8',
'Cookie':cookie,
'Host':'issue.cpic.com.cn',
'Origin':'http://issue.cpic.com.cn',
'Referer':'http://issue.cpic.com.cn/ecar/view/portal/page/quick_quotation/quick_quotation.html',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
'X-Requested-With':'XMLHttpRequest'}
    headers2={'Accept':'application/json, text/javascript, */*; q=0.01',
'Accept-Encoding':'gzip, deflate',
'Accept-Language':'zh-CN,zh;q=0.8',
'Connection':'keep-alive',
'Content-Length':'34',
'Content-Type':'application/json;charset=UTF-8',
'Cookie': cookie,
'Host':'issue.cpic.com.cn',
'Origin':'http://issue.cpic.com.cn',
'Referer':'http://issue.cpic.com.cn/ecar/view/portal/page/quick_quotation/quick_quotation.html',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
'X-Requested-With':'XMLHttpRequest'}
    urls = r'http://issue.cpic.com.cn/ecar/quickoffer/calculate'
    url2 = r"http://issue.cpic.com.cn/ecar/ecar/queryCarModel"
    data2={"meta":{},"redata":{"name":"aa"}}
    headers0={'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Accept-Encoding':'gzip, deflate',
'Accept-Language':'zh-CN,zh;q=0.8',
'Connection':'keep-alive',
'Cookie':cookie,
'Host':'issue.cpic.com.cn',
'Referer':'http://issue.cpic.com.cn/ecar/view/portal/page/quick_quotation/quick_quotation.html',
'Upgrade-Insecure-Requests':'1',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36'}
    response1 = requests.get(r'http://issue.cpic.com.cn/ecar/view/portal/page/quick_quotation/quick_quotation.html',headers=headers0)
    response2 = requests.post(urls,data=json.dumps(data),headers=headers)
    print(response2.text)