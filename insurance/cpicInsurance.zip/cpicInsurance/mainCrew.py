from insurance.cpicInsurance.mysqlUsage import *
from insurance.cpicInsurance.seleniumCrew import *
from insurance.cpicInsurance.typeInfo import *
from insurance.cpicInsurance.usage import sumUpResponse
from dateutil.parser import parse
import datetime
import time
from datetime import timedelta

insuranceList = ['chesuanInsurance',  # 车损
                 'disanfangInsurance',  # 第三方
                 'chedaoInsurance',  # 全车盗抢
                 'sijiInsurance',  # 司机座位责任险
                 'chenkeInsurance',  # 乘客座位责任险
                 'boliInsurance',  # 玻璃单独破碎险
                 'huahenInsurance',  # 车身划痕损失险
                 'ziranInsurance',  # 自燃损失险
                 'fadongjiInsurance',  # 发动机涉水损失险
                 'zhuanxiuInsurance',  # 指定专修厂特约条款
                 'teyueInsurance',  # 无法找到第三方特约险
                 'jiaoqiangInsurance',  # 交强险
                 'chechuanInsurance']  # 车船税

officialList = {'DAMAGELOSSCOVERAGE':{'name':'机动车损失保险','nickname':'车损'},
                'THIRDPARTYLIABILITYCOVERAGE':{'name':'机动车第三者责任保险','nickname':'三者'},
                'INCARDRIVERLIABILITYCOVERAGE':{'name':'机动车车上人员责任保险-司机','nickname':'司机'},
                'INCARPASSENGERLIABILITYCOVERAGE':{'name':'机动车车上人员责任保险-乘客','nickname':'乘客'},
                'THEFTCOVERAGE':{'name':'机动车全车盗抢保险','nickname':'盗抢'},
                'GLASSBROKENCOVERAGE':{'name':'玻璃单独破碎险','nickname':'玻璃'},
                'SELFIGNITECOVERAGE':{'name':'自燃损失险','nickname':'自燃'},
                'CARBODYPAINTCOVERAGE':{'name':'车身划痕损失险','nickname':'划痕'},
                'PADDLEDAMAGECOVERAGE':{'name':'发动机涉水损失险','nickname':'发动机涉水'},
                'APPOINTEDREPAIRFACTORYSPECIALCLAUSE':{'name':'指定修理厂险','nickname':'指定厂'},
                'DAMAGELOSSCANNOTFINDTHIRDSPECIALCOVERAGE':{'name':'机动车损失保险无法找到第三方特约险','nickname':'第三方特约险'}}

def sumUpInfos(info):
    companyId = info['companyName']
    ownerName = info['ownerName']  # 车主姓名
    ownerId   = info['idCard']  # 身份证号
    # certType = ''#预留 接口里暂时没有
    phoneNo   = info['contact']
    print(phoneNo)
    if phoneNo != None:
        if len(phoneNo) != 11:
            phoneNo = '13987654321'  # 手机号
    else:
        phoneNo = '13987654321'
    plateNo        = info['licenseNumber']  # 车牌号x
    engineNo       = info['motorNum']  # 发动机号
    vehicleFrameNo = info['vin']  # 车架号
    firstRegist    = info['initialDate'].strftime('%Y-%m-%d')  # 初等日期
    compStartTime  = info['forceInsuranceStartTime']# 交强险起期
    if (datetime.datetime.now()-compStartTime).days>-1:     #校验起期 日期
        compStartTime = datetime.datetime.now()+timedelta(days=1)
    commStartTime = info['insuranceStartTime']  # 商业险起期
    if (datetime.datetime.now()-commStartTime).days>-1:      #校验起期 日期
        commStartTime = datetime.datetime.now()+timedelta(days=1)
    beginTime_comp = '{}'.format(compStartTime.strftime('%Y-%m-%d'))  # 交强险起期
    beginTime_comm = '{}'.format(commStartTime.strftime('%Y-%m-%d'))  # 商业险起期
    if companyId   == '太平洋保险':
        certType   = typeInfo.pcic[1]
    else:
        certType   = '身份证'
    inquiryInfo    = {
        'ownerInfo':
            {'ownerName': ownerName,
             'ownerId': ownerId,
             'certType': certType,
             'phoneNo': phoneNo},
        'carInfo':
            {'plateNo': plateNo,  # '{}-{}'.format(plateNo[0], plateNo[1:])
             'engineNo': engineNo,
             'vehicleFrameNo': vehicleFrameNo,
             'firstRegist': firstRegist},
        'insuranceInfo':
            {'commInfo': {'beginTime': beginTime_comm},
             'compInfo': {'beginTime': beginTime_comp},
             },
    }
    for insur in insuranceList:
        inquiryInfo['insuranceInfo']['commInfo'][insur]=info[insur]
    return inquiryInfo

def processCookie(cookie_list):
    str_list=[]
    for cookie in cookie_list:
        str_list.append('{}={}'.format(cookie['name'],cookie['value']))
    str=';'.join(str_list)
    return str

def getAccidentProductInfo(orderId,cookie):
    payload = {"meta":{},"redata":{"quotationNo":"{}".format(orderId)}}
    headers = {'Accept':'application/json, text/javascript, */*; q=0.01',
'Accept-Encoding':'gzip, deflate',
'Accept-Language':'zh-CN,zh;q=0.8',
'Connection':'keep-alive',
'Content-Length':'59',
'Content-Type':'application/json;charset=UTF-8',
'Cookie':cookie,
'Host':'issue.cpic.com.cn',
'Origin':'http://issue.cpic.com.cn',
'Referer':'http://issue.cpic.com.cn/ecar/view/portal/page/quick_quotation/quick_quotation.html',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
'X-Requested-With':'XMLHttpRequest'}
    response = requests.post(r'http://issue.cpic.com.cn/ecar/quickoffer/queryQuickOffer',data=json.dumps(payload),headers=headers)
    try:
        response = response.json()

    except Exception as e:
        response = {"message":{"code":"falied","message":"","status":""}}
    quotesInfo = {}
    dictionary={}
    if response['message']['code']=='success':
        print(response)
        # 车信息
        carInfo = response['result']['ecarvo']
        quotesInfo['carInfo']={}
        quotesInfo['carInfo']['carVIN']=carInfo['carVIN']#车架号
        quotesInfo['carInfo']['certNo'] = carInfo['certNo']#证件号
        quotesInfo['carInfo']['engineNo'] = carInfo['engineNo']#发动机号
        quotesInfo['carInfo']['factoryType'] = carInfo['factoryType']#厂牌型号
        quotesInfo['carInfo']['stRegisterDate'] = carInfo['stRegisterDate']#初登日期
        #quotesInfo['carInfo']['phoneNo'] = carInfo['phoneNo']#车主手机号码
        quotesInfo['carInfo']['plateNo'] = carInfo['plateNo']#车牌号
        quotesInfo['carInfo']['ownerName'] = carInfo['ownerName']#车主姓名
        quotesInfo['carInfo']['plateColor'] = plateInfo[int(carInfo['plateColor'])]#号牌种类
        quotesInfo['carInfo']['emptyWeight'] = carInfo['emptyWeight']  #核定载质量
        quotesInfo['carInfo']['usage'] = carInfo['usage']  #使用性质 0非营运 1营运
        quotesInfo['carInfo']['isTrade'] = 0  #是否过户 预留字段

        if response['result']['commercial']:#商业险
            commInfo = response['result']['commercialInsuransVo']
            quotesInfo['commercialInsuransVo']={}
            quotesInfo['commercialInsuransVo']['nonClaimDiscountRate']        = commInfo['nonClaimDiscountRate']#无赔偿折扣系数
            quotesInfo['commercialInsuransVo']['trafficTransgressRate']       = commInfo['trafficTransgressRate']#交通违法系数
            quotesInfo['commercialInsuransVo']['comm_underwritingRate']       = commInfo['underwritingRate']  # 自主核保系数
            quotesInfo['commercialInsuransVo']['comm_channelRate']             = commInfo['channelRate']  # 自主渠道系数
            quotesInfo['commercialInsuransVo']['stStartDate']                   = commInfo['stStartDate']#起保时间
            quotesInfo['commercialInsuransVo']['stEndDate']                     = commInfo['stEndDate']#终保时间
            quotesInfo['commercialInsuransVo']['comm_ecompensationRate']      = commInfo['ecompensationRate']#预期赔付率
            quotesInfo['commercialInsuransVo']['comm_insuranceQueryCode']     =commInfo['insuranceQueryCode'] #商业险 投保查询码
            quotesInfo['commercialInsuransVo']['comm_totalEcompensationRate'] = commInfo['totalEcompensationRate']#交商合计预期赔付率
            quotesInfo['commercialInsuransVo']['comm_standardPremium']         = commInfo['standardPremium']#标准保费
            quotesInfo['commercialInsuransVo']['premium']                        = commInfo['premium']#折后保费
            quotesInfo['commercialInsuransVo']['comm_premiumRatio']            = commInfo['premiumRatio']#折扣率

        if response['result']['compulsory']:#交强险
            compInfo = response['result']['compulsoryInsuransVo']
            quotesInfo['compulsoryInsuransVo'] = {}
            quotesInfo['compulsoryInsuransVo']['comp_ecompensationRate']  = compInfo['ecompensationRate']#预期赔付率
            quotesInfo['compulsoryInsuransVo']['comp_insuranceQueryCode'] = compInfo['insuranceQueryCode']#投保查询码
            quotesInfo['compulsoryInsuransVo']['comp_payableAmount']      = compInfo['payableAmount']#当年应缴
            quotesInfo['compulsoryInsuransVo']['comp_registryNumber']     = compInfo['registryNumber']#税务登记号
            quotesInfo['compulsoryInsuransVo']['comp_standardPremium']    = compInfo['standardPremium']#交强险保费
            quotesInfo['compulsoryInsuransVo']['comp_taxAmount']          = compInfo['taxAmount']#车船税保费
            quotesInfo['compulsoryInsuransVo']['comp_totalPremium']       = compInfo['totalPremium']#交强险总计费用
            quotesInfo['compulsoryInsuransVo']['comp_taxpayerName']       = compInfo['taxpayerName']#纳税人名
            quotesInfo['compulsoryInsuransVo']['comp_taxpayerNo']         = compInfo['taxpayerNo']#身份证号
        commDetail = response['result']['quoteInsuranceVos']
        sumPrice = response['result']['totalPremium']
        nonDeductible = []
        nonDeductiblePrice=0
        for quote in commDetail:
            insurName = quote['insuranceCode']
            if 'DAMAGELOSSCOVERAGE'==insurName:
                DamageLossCoverage = quote['stAmount']
            if insurName in officialList:
                #名字 = 折后价
                quotesInfo['commercialInsuransVo'][insurName]={'premium':quote['premium']}
                if 'nonDeductible' in quote:
                    nonDeductible.append(officialList[insurName]['nickname'])
                    nonDeductiblePrice+=quote['nonDeductible']
                    #print(nonDeductiblePrice)
        dictionary = {'codeNo': orderId,
                      'sumPrice':sumPrice,
                      'quotesInfo': quotesInfo,
                      'nonDeductible': {'name': '、'.join(nonDeductible), 'value': nonDeductiblePrice}}
        try:
            dictionary['DamagePrice']=DamageLossCoverage
        except Exception as e:
            pass
    return dictionary

def getInsurInfo():
    while True:
        infos = getOnePiece()
        if infos:#如果查到 未完成的 数据
            driver = webdriver.Chrome()
            driver.set_window_size(1280, 800)
            driver.implicitly_wait(10)
            info = infos[0]
            #try:
            for insur in insuranceList:
                if info[insur]:
                    stredInfo = re.sub('”|“', '"', info[insur])
                    info[insur] = eval(stredInfo)
            #封装一个整理数据的模型
            InquiryInfo = sumUpInfos(info)
            print(InquiryInfo)
            #更新一下库状态
            updateInquiryInput(info['id'])#这一步更新input表
            updateInquiryWaitCount(1,info['inquiryId'])#这一步增加wait数量
            #开始爬取数据的maincrew
            orderInfo = TaiPingYangCrew(driver, infos=InquiryInfo)
            print(orderInfo)
            if orderInfo['status']==1:
                updateInquirySuccessCount(quiryId=info['inquiryId'])
                cookieList = driver.get_cookies()
                cookie = processCookie(cookie_list=cookieList)
                res_dictionary = getAccidentProductInfo(orderId=orderInfo['code'],cookie=cookie)#爬到的保单信息
                #print(res_dictionary)
                reptileDict = sumUpResponse(inquiryInfo=info,error_message=orderInfo['error_message'],res_dictionary=res_dictionary)
                reptileDict['ownerContact']=info['ownerContact']
                reptileDict['caseName'] = info['planName']  # 方案名称
                insertSuccessReptile(reptileDict)
            elif orderInfo['status']==0:
                updateInquiryErrorCount(quiryId=info['inquiryId'])
                reptileDict={'id':info['id'],
                             'inquiryId':info['inquiryId'],
                             'isRenewal':info['isRenewal'],
                             'cityName':info['cityName'],
                             'licenseNumber':info['licenseNumber'],
                             'ownerName':info['ownerName'],
                             'idCard':info['idCard'],
                             'vin':info['vin'],
                             'motorNum':info['motorNum'],
                             'caseName':info['planName'],
                             'state':2,
                             'createTime':datetime.datetime.now(),
                             'updateTime':datetime.datetime.now(),
                             'initialDate':info['initialDate'],
                             'ownerContact':info['ownerContact'],
                             'company':info['companyName'],
                             'message':orderInfo['error_message'],
                             }
                insertFailedReptile(reptileDict)
            #至此全部爬取完毕
            print('3 秒后查询下一条')
            driver.quit()
            time.sleep(3)
            # except Exception as e:
            #     updateInquiryErrorCount(quiryId=info['inquiryId'])
            #     reptileDict = {'id': info['id'],
            #                    'inquiryId': info['inquiryId'],
            #                    'isRenewal': info['isRenewal'],
            #                    'cityName': info['cityName'],
            #                    'licenseNumber': info['licenseNumber'],
            #                    'ownerName': info['ownerName'],
            #                    'idCard': info['idCard'],
            #                    'vin': info['vin'],
            #                    'motorNum': info['motorNum'],
            #                    'caseName': info['planName'],
            #                    'state': 2,
            #                    'createTime': datetime.datetime.now(),
            #                    'updateTime': datetime.datetime.now(),
            #                    'initialDate': info['initialDate'],
            #                    'ownerContact': info['ownerContact'],
            #                    'company': info['companyName'],
            #                    'message': orderInfo['error_message'],
            #                    }
            #     insertFailedReptile(reptileDict)
        else:#没有查到 未完成 数据
            print('没有查到未完成条目，30秒后重新扫描')
            time.sleep(30)



if __name__ == '__main__':
    getInsurInfo()