import pymysql
import contextlib
import re
import datetime
import time
#ALTER TABLE tab_name  MODIFY COLUMN update_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

@contextlib.contextmanager
#host='127.0.0.1',port=3306,user='root',passwd='941208',db='cookiestorage',charset='utf8'
#host='121.40.207.59',port=3306,user='root',passwd='MmIAN8kX',db='cookiestorage',charset='utf8'
def mysql(host='121.40.207.59',port=3306,user='root',passwd='MmlAN8kX',db='ggcx',charset='utf8'):
  conn = pymysql.connect(host=host, port=port, user=user, passwd=passwd, db=db, charset=charset)
  cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)
  try:
    yield cursor
  finally:
    conn.commit()
    cursor.close()
    conn.close()

def updateCookies(id,value):
    with mysql() as cursor:
        sql_content = "UPDATE cookies SET cookie='{}' WHERE id={}".format(value,id)
        c = cursor.execute(sql_content)

def getCookies(id):
    with mysql() as cursor:
        sql_content = "SELECT * from cookies WHERE id={}".format(id)
        c = cursor.execute(sql_content)
        return cursor.fetchall()[0]

def inquiryInfo(promtCode):
    with mysql() as cursor:
        sql_content = "SELECT * from promt WHERE promtCode='{}'".format(promtCode)
        c = cursor.execute(sql_content)
        return cursor.fetchall()

def updateInfo(document):
    with mysql() as cursor:
        c = cursor.execute("INSERT INTO promt(statis,companyName,place,promtCode,idNumber, insurName, holderName,insuredName,beginTime,policy_static,policy_name,policy_code,endTime,InquiryStatic) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
            document['statis'],
            document['companyName'],
            document['place'],
            document['promtCode'],
            document['idNumber'],
            document['insurName'],
            document['holderName'],
            document['insuredName'],
            document['beginTime'],
            document['policy_static'],
            document['policy_name'],
            document['policy_code'],
            document['endTime'],
            document['InquiryStatic']))

def processCookie(document):
    str=''
    for doc in document:
        str = ''.join([str,doc,'=',document[doc],';'])
    return str
#以上为原项目=====================================================================

#以下是呱呱车险的查询条件
def PASS():
    pass

#update Input表里的状态
def updateInquiryInput(id):
    with mysql() as cursor:
        sql_content = "UPDATE inquiry_input SET state=1 WHERE id='{}'".format(id)
        c = cursor.execute(sql_content)

#update 等待数量
def updateInquiryWaitCount(form,quiryId):
    with mysql() as cursor:
        if form==1:
            sql_content = "UPDATE inquiry SET waitCount=waitCount+1 WHERE quiryId='{}'".format(quiryId)
        elif form==-1:
            sql_content = "UPDATE inquiry SET waitCount=waitCount-1 WHERE quiryId='{}'".format(quiryId)
        c = cursor.execute(sql_content)

#update 失败数量
def updateInquiryErrorCount(quiryId):
    with mysql() as cursor:
        sql_content = "UPDATE inquiry SET waitCount=waitCount-1,errorCount=errorCount+1 WHERE quiryId='{}'".format(quiryId)
        c = cursor.execute(sql_content)
        # sql_content = "SELECT COUNT(*) FROM inquiry_input WHERE inquiryId='{}'".format(quiryId)
        # c = cursor.execute(sql_content)
        # sums = cursor.fetchall()[0]
        # sql_content = "SELECT errorCount FROM inquiry WHERE quiryId='{}'".format(quiryId)
        # c = cursor.execute(sql_content)
        # failTimes = cursor.fetchall()[0]
        # if sums==failTimes:
        #     sql_content = "UPDATE inquiry SET state= WHERE quiryId='{}'".format(quiryId)
        #     c = cursor.execute(sql_content)
#update 成功数量
def updateInquirySuccessCount(quiryId):
    with mysql() as cursor:
        sql_content = "UPDATE inquiry SET waitCount=waitCount-1,successCount=successCount+1,state=1 WHERE quiryId='{}'".format(quiryId)
        c = cursor.execute(sql_content)

#获取input里单条数据
def getOnePiece():
    with mysql() as cursor:
        sql_content = "SELECT * from inquiry_input WHERE state=0 ORDER BY createTime LIMIT 1"
        c = cursor.execute(sql_content)
        infos = cursor.fetchall()
    return infos

def insertSuccessReptile(reptile_dict):
    with mysql() as cursor:
        c = cursor.execute("INSERT INTO inquiry_reptile(inquiryInputId,inquiryId,isRenewal,cityName,licenseNumber,ownerName,idCard,carTypeCode,approvedLoadQuality,operation,households,chesuanInsurancePrice,disanfangInsurancePrice,chedaoInsurancePrice,sijiInsurancePrice,chenkeInsurancePrice,boliInsurancePrice,huahenInsurancePrice,ziranInsurancePrice,fadongjiInsurancePrice,zhuanxiuInsurancePrice,teyueInsurancePrice,jiaoqiangInsurancePrice,chechuanInsurancePrice,insuranceCompanyId,quotesPrice,insuranceCompanyNametwo,policyNo,quotesPricetwo,insurancePrice,vin,motorNum,labeltype,caseName,insurances,state,createTime,updateTime,initialDate,ownerContact,company,companyEndDate,insuranceCompanyNameOne,policyOneNo,insuranceCompanyOneStartDate,insuranceCompanyOneEndDate,insuranceCompanyTwoStartDate,insuranceCompanyTwoEndDate,message,rate,chesuanInsuranceBaoe,bujimianpeiName,bujimianpeiPrice,manageCoefNum,illegalCoefNum,selfChannelNum,selfUnderNum,allMessage) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
            reptile_dict['id'],
            reptile_dict['inquiryId'],
            reptile_dict['isRenewal'],
            reptile_dict['cityName'],
            reptile_dict['licenseNumber'],
            reptile_dict['ownerName'],
            reptile_dict['idCard'],
            reptile_dict['carTypeCode'],
            reptile_dict['approvedLoadQuality'],
            reptile_dict['operation'],
            reptile_dict['households'],
            reptile_dict['chesuanInsurancePrice'],
            reptile_dict['disanfangInsurancePrice'],
            reptile_dict['chedaoInsurancePrice'],
            reptile_dict['sijiInsurancePrice'],
            reptile_dict['chenkeInsurancePrice'],
            reptile_dict['boliInsurancePrice'],
            reptile_dict['huahenInsurancePrice'],
            reptile_dict['ziranInsurancePrice'],
            reptile_dict['fadongjiInsurancePrice'],
            reptile_dict['zhuanxiuInsurancePrice'],
            reptile_dict['teyueInsurancePrice'],
            reptile_dict['jiaoqiangInsurancePrice'],
            reptile_dict['chechuanInsurancePrice'],
            reptile_dict['insuranceCompanyId'],
            reptile_dict['quotesPrice'],
            reptile_dict['insuranceCompanyNametwo'],
            reptile_dict['policyNo'],
            reptile_dict['quotesPricetwo'],
            reptile_dict['insurancePrice'],
            reptile_dict['vin'],
            reptile_dict['motorNum'],
            reptile_dict['labeltype'],
            reptile_dict['caseName'],
            reptile_dict['insurances'],
            reptile_dict['state'],
            reptile_dict['createTime'],
            reptile_dict['updateTime'],
            reptile_dict['initialDate'],
            reptile_dict['ownerContact'],
            reptile_dict['company'],
            reptile_dict['companyEndDate'],
            reptile_dict['insuranceCompanyNameOne'],
            reptile_dict['policyOneNo'],
            reptile_dict['insuranceCompanyOneStartDate'],
            reptile_dict['insuranceCompanyOneEndDate'],
            reptile_dict['insuranceCompanyTwoStartDate'],
            reptile_dict['insuranceCompanyTwoEndDate'],
            '询价成功',
            reptile_dict['rate'],
            reptile_dict['chesuanInsuranceBaoe'],
            reptile_dict['bujimianpeiName'],
            reptile_dict['bujimianpeiPrice'],
            reptile_dict['manageCoefNum'],
            reptile_dict['illegalCoefNum'],
            reptile_dict['selfChannelNum'],
            reptile_dict['selfUnderNum'],
            reptile_dict['message']
        ))

def insertFailedReptile(reptile_dict):
    with mysql() as cursor:
        c = cursor.execute("INSERT INTO inquiry_reptile(inquiryInputId,inquiryId,isRenewal,cityName,licenseNumber,ownerName,idCard,vin,motorNum,caseName,state,createTime,updateTime,initialDate,ownerContact,company,message,allMessage) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
            reptile_dict['id'],
            reptile_dict['inquiryId'],
            reptile_dict['isRenewal'],
            reptile_dict['cityName'],
            reptile_dict['licenseNumber'],
            reptile_dict['ownerName'],
            reptile_dict['idCard'],
            reptile_dict['vin'],
            reptile_dict['motorNum'],
            reptile_dict['caseName'],
            reptile_dict['state'],
            reptile_dict['createTime'],
            reptile_dict['updateTime'],
            reptile_dict['initialDate'],
            reptile_dict['ownerContact'],
            reptile_dict['company'],
            '询价失败',
            reptile_dict['message']
        ))


if __name__ == '__main__':
    a = getOnePiece()
    print(a)