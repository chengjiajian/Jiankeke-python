from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.support.ui import WebDriverWait
import re
from PIL import Image
from selenium.common.exceptions import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
class mainDriver:
    def __init__(self,quotationNoList):
        self.cpic = webdriver.PhantomJS()
        self.cpic.set_window_size(1280, 800)
        self.quotationNoList = quotationNoList

    def Login(self):
        cpic = self.cpic
        print('正在转到首页')
        cpic.get(r'http://issue.cpic.com.cn/ecar/view/portal/page/common/login.html')
        username = cpic.find_element_by_xpath(r'//*[@id="j_username"]')
        username.clear()
        username.send_keys('w_CD_VSD_001')
        cpic.find_element_by_xpath(r'//*[@id="_password"]').send_keys('Cpic1218')
        validCode = cpic.find_element_by_xpath(r'//*[@id="verifyCode"]')
        imageLocate = cpic.find_element_by_xpath(r'//*[@id="capImg"]')
        savePath = 'validcode.png'
        cpic.save_screenshot(savePath)
        location = imageLocate.location  # 获取验证码x,y轴坐标
        size = imageLocate.size  # 获取验证码的长宽
        rangle = (int(location['x']), int(location['y']), int(location['x'] + size['width']),
                  int(location['y'] + size['height']))  # 写成我们需要截取的位置坐标
        i = Image.open(savePath)  # 打开截图
        frame4 = i.crop(rangle)  # 使用Image的crop函数，从截图中再次截取我们需要的区域
        frame4.save('validcode.png')  # 保存接下来的验证码图片 进行打码
        # validCode.send_keys(validcode)
        validCode.send_keys(input('input valicode'))
        cpic.find_element_by_xpath(r'//*[@id="j_login"]').click()
        print('正在登陆')
        while True:
            pageContent = cpic.page_source
            if '终端及经办人选择' in pageContent:
                print('登陆成功，正在选择业务员')
                if '何爱国' in pageContent:
                    break
                print('暂未加载出 何爱国，重试中')
                time.sleep(1)
            elif '验证码错误' in pageContent or '用户名或密码错误' in pageContent or '验证码不能为空' in pageContent:
                print('发送错误，重新登陆')
                self.paycrewer()
        cpic.find_element_by_xpath(r'//*[@id="__agent_2__"]').click()
        cpic.find_element_by_xpath(r'//*[@id="loginBtn"]').click()
        WebDriverWait(cpic, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'width-2')))
        time.sleep(1)

    def inquiryQuotation(self):
        cpic = self.cpic
        print('正在点击 查询按钮')
        cpic.find_element_by_xpath(r'/html/body/div[2]/div[2]/div/div[3]/a').click()
        for quotationNo in self.quotationNoList:
            print('正在输入 查询单号 {}'.format(quotationNo))
            cpic.find_element_by_xpath(r'//*[@id="quotationNo"]').send_keys(quotationNo)
            cpic.find_element_by_xpath(r'//*[@id="search"]').click()
            print('点击查询')
            WebDriverWait(cpic, 10).until(EC.presence_of_element_located((By.ID, 'resultTable')))
            print('查询中，请等待结果')
            time.sleep(3)
            quotationBotton = cpic.find_element_by_xpath(r'//*[@id="resultTable"]/tbody/tr[1]/td[2]')
            #input('going to click')
            ActionChains(cpic).double_click(quotationBotton).perform()
            input('get pagesource')
            print(cpic.page_source)
    def paycrewer(self):
        pass


if __name__ == '__main__':
    CPIC = mainDriver(quotationNoList=['QCHDA81Y1418F007588N',])
    CPIC.Login()
    CPIC.inquiryQuotation()