from selenium import webdriver
from bs4 import BeautifulSoup
import requests
import json
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.support.ui import WebDriverWait
import re
from selenium.common.exceptions import *
from selenium.webdriver.support import expected_conditions as EC
from insurance.cpicInsurance import typeInfo
from insurance.cpicInsurance.mainCrew import processCookie
import base64
from PIL import Image

def dpi_request(path,codeType):
    try:
        print('接口调用成功')
        with open(path,'rb') as s:
            ls_f = base64.b64encode(s.read())  # 读取文件内容，转换为base64编码
            #print(ls_f)
            url = "http://op.juhe.cn/vercode/index"
            params = {
                "key": '889fdc9bc1d1e5e678e52623b23c1f7a',  # 您申请到的APPKEY
                "codeType": codeType,
            # 验证码的类型，&lt;a href=&quot;http://www.juhe.cn/docs/api/id/60/aid/352&quot; target=&quot;_blank&quot;&gt;查询&lt;/a&gt;
                "base64Str": ls_f,  # 图片文件
                "dtype": "",  # 返回的数据的格式，json或xml，默认为json

            }
            #print(params)
            #input('')
            # with open (r'C:\Users\ASUS\Desktop\x.txt','wb+') as f:
            #     f.write(ls_f)
            f = requests.post(url=url, data=params,timeout=120)
            res = f.json()
            print('res',res)
            if res:
                error_code = res["error_code"]
                if error_code == 0:
                    # 成功请求
                    print(res["result"])
                else:
                    print("%s:%s" % (res["error_code"], res["reason"]))
            else:
                print("request api error")
        return res["result"]
    except Exception as e:
        dpi_request(path, codeType)

def cropValidcode(savePath,driver,imageElement,validType):
    driver.save_screenshot(savePath)
    location = imageElement.location  # 获取验证码x,y轴坐标
    size = imageElement.size  # 获取验证码的长宽
    rangle = (int(location['x']), int(location['y']), int(location['x'] + size['width']),
              int(location['y'] + size['height']))  # 写成我们需要截取的位置坐标
    i = Image.open(savePath)  # 打开截图
    frame4 = i.crop(rangle)  # 使用Image的crop函数，从截图中再次截取我们需要的区域
    frame4.save(savePath)  # 保存接下来的验证码图片 进行打码
    validcodeNum = dpi_request(savePath,validType)
    return validcodeNum

def clickUnderBotton(carInfo,error_dict,driver):
    #input('点击试算')
    driver.find_element_by_xpath(r'//*[@id="premiumTrial"]/img').click()
    time.sleep(3)
    error_dict['status']=1
    error_message='询价成功'
    while True:
        #处理弹窗
        try:
            #input('点击暂存')
            driver.find_element_by_xpath(r'//*[@id="temporary"]/img').click()
            #input('成功点击暂存，跳出循环')
            break
        except Exception as e:
            #input('暂存失败，异常处理')
            time.sleep(1)
            PageContent = driver.page_source
            if '提示信息'and '所选车型不一致' in PageContent:
                #input('提示信息')
                error_reg = re.compile('平台对应车型代码有：(.*?)</div>')
                error_message = re.findall(error_reg, PageContent)[0]
                cookieList = driver.get_cookies()
                cookie = processCookie(cookie_list=cookieList)
                response = carModelQuery(targetID=error_message, carInfos=carInfo, cookie=cookie)
                try:
                    driver.find_element_by_xpath(r'/html/body/div[21]/div[2]/div[2]/a').click()
                except Exception as e:
                    pass
                if response['code'] == 1:
                    driver.find_element_by_xpath(r'/html/body/div[20]/div[2]/div[2]/a').click()
                    driver.find_element_by_xpath(r'//*[@id="plateNo"]').send_keys(Keys.TAB)
                    driver.find_element_by_xpath(r'//*[@id="modelType"]').click()
                    driver.find_element_by_xpath(r'//*[@id="modelType"]').send_keys(Keys.BACK_SPACE)
                    time.sleep(1)
                    xp = '//*[@id="ecarvoForm"]/div[1]/div[14]/div[2]/ul/li[{}]'.format(response['foundid'])
                    driver.find_element_by_xpath(xp).click()
                    clickUnderBotton(carInfo, error_dict, driver)
            elif '警示信息' in PageContent:
                #input('警示信息')
                soup = BeautifulSoup(PageContent, 'lxml')
                if '商业险重复投保' in PageContent:
                    error_dict['status'] = 0
                    #input('商业险重复投保')
                    tag = soup.find_all('div')
                    error_message = tag[-2].get_text()  # 预留的errormessage信息口子
                    driver.find_element_by_xpath(r'/html/body/div[20]/div[2]/div[2]/a').click()
                else:
                    error_dict['status'] = 0
                    error_message = PageContent
                time.sleep(1)
            elif '错误信息' in PageContent:
                #input('错误信息')
                error_dict['status'] = 0
                error_reg = re.compile('\[保费计算\]保费计算失败，错误信息为\[(.*)\]')
                error_message = re.findall(error_reg, PageContent)[0]
                #input(error_message)
                driver.find_element_by_xpath(r'/html/body/div[20]/div[2]/div[2]/a').click()
                time.sleep(1)
            else:
                #input('既不是提示 也不是警示 也不是错误')
                try:
                    #input('')
                    driver.find_element_by_xpath(r'/html/body/div[20]/div[2]/div[2]/a').click()
                    error_dict['status'] = 1
                    error_message = '成功关闭'
                except Exception as e:
                    error_message=''
                    #input('关闭失败')
                    time.sleep(1)
    error_dict['error_message'] = error_message
    return error_dict

def carModelQuery(targetID,carInfos,cookie):
    carName = carInfos.split('/')[0].strip()
    print(carName)
    urls = r'http://issue.cpic.com.cn/ecar/ecar/queryCarModel'
    headers = {'Accept':'application/json, text/javascript, */*; q=0.01',
'Accept-Encoding':'gzip, deflate',
'Accept-Language':'zh-CN,zh;q=0.8',
'Connection':'keep-alive',
'Content-Length':'46',
'Content-Type':'application/json;charset=UTF-8',
'Cookie':cookie,
'Host':'issue.cpic.com.cn',
'Origin':'http://issue.cpic.com.cn',
'Referer':'http://issue.cpic.com.cn/ecar/view/portal/page/quick_quotation/quick_quotation.html',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36',
'X-Requested-With':'XMLHttpRequest'}
    payload={"meta":{},"redata":{"name":carName}}
    response = requests.post(url=urls,data=json.dumps(payload),headers=headers)
    return_info={}
    try:
        response = response.json()
        if response['message']['code']=='success':
            results = response['result']
            for countNum in range(0,len(results)):
                info = results[countNum]
                if targetID==info['moldCharacterCode']:
                    return_info['code']=1
                    return_info['foundid'] = countNum + 1
                    break
                else:
                    return_info['code']=0

    except  Exception as e:
        return_info['code'] = 0
    return return_info

def RollPage(driver,rollLong):
    js = "var q=document.body.scrollTop={}".format(rollLong)
    driver.execute_script(js)

def TaiPingYangCrew(driver,infos):
    error_dict = {}
    driver.get(r'http://issue.cpic.com.cn/ecar/view/portal/page/common/login.html')
    username    = driver.find_element_by_xpath(r'//*[@id="j_username"]')
    username.clear()
    username.send_keys('w_CD_VSD_001')
    driver.find_element_by_xpath(r'//*[@id="_password"]').send_keys('Cpic1218')
    validCode   = driver.find_element_by_xpath(r'//*[@id="verifyCode"]')
    imageLocate = driver.find_element_by_xpath(r'//*[@id="capImg"]')
    savePath    = 'validcode.png'
    validcode   = cropValidcode(savePath=savePath, driver=driver, imageElement=imageLocate, validType=1004)
    validCode.send_keys(validcode)
    #validCode.send_keys(input('input valicode'))
    driver.find_element_by_xpath(r'//*[@id="j_login"]').click()
    while True:
        pageContent = driver.page_source
        if '终端及经办人选择' in pageContent:
            if '何爱国' in pageContent:
                break
            time.sleep(1)
        elif '验证码错误' in pageContent or '用户名或密码错误' in pageContent or '验证码不能为空' in pageContent:
            TaiPingYangCrew(driver, infos)
    driver.find_element_by_xpath(r'//*[@id="__agent_2__"]').click()
    driver.find_element_by_xpath(r'//*[@id="loginBtn"]').click()
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'width-2')))
    time.sleep(1)
    driver.find_element_by_xpath('/html/body/div[2]/div[2]/div/div[1]/a/img').click()
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'VINSearch')))
    time.sleep(1)
    plate = driver.find_element_by_xpath(r'//*[@id="plateNo"]')
    plate.clear()
    plate.send_keys(infos['carInfo']['plateNo'])#车牌号
    vinNo = infos['carInfo']['vehicleFrameNo']
    WebDriverWait(driver,10).until(EC.presence_of_element_located((By.ID,'modelType')))
    # driver.find_element_by_xpath(r'//*[@id="carVIN"]').send_keys(vinNo)
    for i in vinNo:
        vinInput =driver.find_element_by_xpath(r'//*[@id="carVIN"]')
        vinInput.send_keys(i)#车架号
        driver.find_element_by_xpath(r'//*[@id="engineNo"]').click()
    driver.find_element_by_xpath(r'//*[@id="engineNo"]').send_keys(infos['carInfo']['engineNo'])  # 发动机号
    driver.find_element_by_xpath(r'//*[@id="stRegisterDate"]').send_keys(infos['carInfo']['firstRegist'])  # 初等日期
    driver.find_element_by_xpath(r'//*[@id="VINSearch"]').click()
    # Vin码查询
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="carTypeTable"]/tbody/tr[1]/td[2]')))
        try:    #获取座位信息
            carInfo = driver.find_element_by_xpath(r'//*[@id="carTypeTable"]/tbody/tr').text
            print(carInfo)
            chairs_reg = re.compile('/(\w+)座')
            try:
                chairs = int(re.findall(chairs_reg,carInfo)[0])
                driver.find_element_by_xpath(r'//*[@id="carTypeTable"]/tbody/tr[1]/td[1]/input').click()
                driver.find_element_by_xpath(r'//*[@id="carTypeDialog"]/div[2]/div[2]/a[1]').click()
                #以上退出了vin码查询页面
                #以下开始选座位用途
                type_selector = Select(driver.find_element_by_id('vehicleType'))
                usage_selector = Select(driver.find_element_by_id('vehiclePurpose'))
                if chairs < 6:
                    car_type = '6座以下客车'
                    car_usage = '9座以下客车'
                elif chairs>=6 and chairs<10:
                    car_type = '6座及10座以下客车'
                    car_usage = '9座以下客车'
                elif chairs >= 10 and chairs < 20:
                    car_type = '10座及20座以下客车'
                    car_usage = '10座以上客车'
                elif chairs >= 20 and chairs < 36:
                    car_type = '20座及36座以下客车'
                    car_usage = '10座以上客车'
                elif chairs >= 36:
                    car_type = '36座及36座以下客车'
                    car_usage = '10座以上客车'
                #根据车类型 来选择
                type_selector.select_by_visible_text(car_type)  # 证件类型
                time.sleep(1)
                usage_selector.select_by_visible_text(car_usage)  # 证件类型
                #车主信息填写
                driver.find_element_by_xpath(r'//*[@id="ecarvoForm"]/div[1]/div[26]/input').send_keys(infos['ownerInfo']['ownerName'])#车主姓名
                s1 = Select(driver.find_element_by_id('certType'))
                s1.select_by_visible_text(infos['ownerInfo']['certType'])#证件类型
                driver.find_element_by_xpath(r'//*[@id="certNo"]').send_keys(infos['ownerInfo']['ownerId'])#证件号码
                compDate = driver.find_element_by_xpath(r'//*[@id="compulsoryStartDate"]')  # 交强险起期
                compDate.clear()
                compDate.send_keys('{} 00:00'.format(infos['insuranceInfo']['compInfo']['beginTime']))
                commDate = driver.find_element_by_xpath(r'//*[@id="commercialStartDate"]')  # 商业险起期
                commDate.clear()
                commDate.send_keys('{} 00:00'.format(infos['insuranceInfo']['commInfo']['beginTime']))

                # 调整页面位置
                locate = driver.find_element_by_xpath(r'//*[@id="rate"]')
                locate.send_keys(Keys.TAB)
                locate.send_keys(Keys.TAB)
                # ===============================================交强险入口勾选情况
                if infos['insuranceInfo']['commInfo']['jiaoqiangInsurance']['baoe']=='不投保':
                    driver.find_element_by_xpath('//*[@id="compulsoryInput"]').click()

                # ===============================================车辆损失险
                CheSun    = infos['insuranceInfo']['commInfo']['chesuanInsurance']
                if CheSun['baoe']    == '投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox3"]').click()#勾选车损
                    if CheSun['insuranceType']==0:
                        #取消 不计免赔 的勾
                        driver.find_element_by_xpath(r'//*[@id="checkbox4"]').click()

                # ===============================================第三方
                DiSanFang = infos['insuranceInfo']['commInfo']['disanfangInsurance']
                if DiSanFang['baoe'] != '不投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox5"]').click()#勾选三者险
                    selector = Select(driver.find_element_by_id('thirdInsuranceAmount'))
                    selector.select_by_visible_text(DiSanFang['baoe'])  # 保额选择
                    if DiSanFang['insuranceType']==0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox6"]').click()#取消 不计免赔 的勾


                # ===============================================全车盗抢
                QiangDao = infos['insuranceInfo']['commInfo']['chedaoInsurance']
                if QiangDao['baoe'] =='投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox10"]').click()#勾选抢盗险
                    if QiangDao['insuranceType']==0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox11"]').click()#取消 不计免赔勾选
                # ===============================================司机座位责任险
                SiJi = infos['insuranceInfo']['commInfo']['sijiInsurance']
                if SiJi['baoe']     !='不投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox7"]').click()#勾选司机险
                    sijiValue = driver.find_element_by_xpath(r'//*[@id="pLI"]')
                    if SiJi['insuranceType']==0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox77"]').click()#取消 不计免赔勾选
                    sijiValue.click()
                    for i in range(10):
                        sijiValue.send_keys(Keys.BACK_SPACE)
                    sijiValue.send_keys(SiJi['baoe'])
                # ===============================================乘客座位责任险
                ChengKe = infos['insuranceInfo']['commInfo']['chenkeInsurance']
                if ChengKe['baoe']  != '不投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox8"]').click()  # 勾选乘客险
                    if ChengKe['insuranceType'] == 0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox88"]').click()  # 取消 不计免赔勾选
                    chengkeValue = driver.find_element_by_xpath(r'//*[@id="seatPrice"]')
                    for i in range(10):
                        chengkeValue.send_keys(Keys.BACK_SPACE)
                    chengkeValue.send_keys(ChengKe['baoe'])
        # ===============================================# ===============================================
                driver.find_element_by_xpath('//*[@id="rate"]').send_keys(Keys.TAB)#用TAB来控制页面下拉
        # ===============================================# ===============================================
                # ===============================================玻璃单独破碎险
                BoLi = infos['insuranceInfo']['commInfo']['boliInsurance']#
                if BoLi['baoe']     != '不投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox12"]').click() # 勾选 玻璃单独破碎险

                    selector = Select(driver.find_element_by_id('locality'))
                    selector.select_by_visible_text(BoLi['baoe'])  # 玻璃选择
                    #以下预留，太平洋玻璃险没有不计免赔选项
                    # if BoLi['insuranceType']==0:
                    #     driver.find_element_by_xpath(r'//*[@id="checkbox6"]').click()  # 取消 不计免赔 的勾
                # ===============================================车身划痕损失险
                HuaHen = infos['insuranceInfo']['commInfo']['huahenInsurance']
                if HuaHen['baoe']   != '不投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox16"]').click() # 勾选 车身划痕损失险
                    selector = Select(driver.find_element_by_xpath('//*[@id="quoteInsuranceTable"]/tbody/tr[9]/td[3]/select'))
                    selector.select_by_visible_text(HuaHen['baoe'])  # 车身划痕损失险 选择
                    if HuaHen['insuranceType'] == 0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox17"]').click()  # 取消 不计免赔勾选
                # ===============================================自燃损失险
                ZiRan = infos['insuranceInfo']['commInfo']['ziranInsurance']
                if ZiRan['baoe']    == '投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox14"]').click()# 勾选 自燃损失险
                    if ZiRan['insuranceType'] == 0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox15"]').click()  # 取消 不计免赔勾选
                # ===============================================发动机涉水损失险
                SheShui = infos['insuranceInfo']['commInfo']['fadongjiInsurance']
                if SheShui['baoe']  == '投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox18"]').click()  # 勾选 发动机涉水损失险
                    if SheShui['insuranceType'] == 0:
                        driver.find_element_by_xpath(r'//*[@id="checkbox19"]').click()  # 取消 不计免赔勾选
                # ===============================================指定专修厂特约条款
                ZhuanXiu = infos['insuranceInfo']['commInfo']['zhuanxiuInsurance']
                if ZhuanXiu['baoe'] == '投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox28"]').click()  # 勾选 发动机涉水损失险
                    rateInput = driver.find_element_by_xpath(r'//*[@id="rate"]')
                    rateInput.clear()
                    rateInput.send_keys('0.3')
                    #指定专修 没有不计免赔
                    # if ZhuanXiu['insuranceType'] == 0:
                    #     driver.find_element_by_xpath(r'//*[@id="checkbox19"]').click()  # 取消 不计免赔勾选
                # ===============================================无法找到第三方特约险
                TeYue = infos['insuranceInfo']['commInfo']['teyueInsurance']
                if TeYue['baoe']    == '投保':
                    driver.find_element_by_xpath(r'//*[@id="checkbox30"]').click()  # 勾选 无法找到第三方特约险
                print('doing error dict')
                error_dict = clickUnderBotton(carInfo=carInfo,error_dict=error_dict,driver=driver)
                time.sleep(1)
                print('314')
                driver.find_element_by_xpath(r'/html/body/div[20]/div[2]/div[2]/a').click()
                code_reg = re.compile('<span id="billCode">(.*?)</span>')
                code = re.findall(code_reg,driver.page_source)
                print('318')
                if code:
                    print(code)
                    driver.find_element_by_xpath(r'//*[@id="title"]/li[4]/a/img').click()
                    error_dict['code'] = code[0]
                    #print(error_dict,'328')
                else:
                    print('329')
                    pass
            except Exception as e:
                print('321 except Exception as e:')
                print(e)
                #input('check    except Exception as e:')
                error_dict['status']=0
                error_dict['error_message'] = e
        except UnexpectedAlertPresentException as e:
            print('except UnexpectedAlertPresentException as e')
            reg = re.compile('unexpected alert open: \{Alert text : (.*)\?\}')
            error_dict['status'] = 0
            error_dict['error_message'] = re.findall(reg,str(e))[0]
    except Exception as e:
        error_dict['status'] = 0
        error_dict['error_message'] = 'vin码校验错误'
    return error_dict


if __name__ == '__main__':
    pass