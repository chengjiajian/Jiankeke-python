from dateutil.parser import parse
import datetime
import time
from datetime import timedelta


class mainTest:
    def __init__(self,driver,name='default'):
        self.driver = driver
        super
        self.name = name

    def _showInfo(self):
        print(self.driver)
        print(self.name)

if __name__ == '__main__':
    pass
    #a = lambda x:
    #print(a(3))