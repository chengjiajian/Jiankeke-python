import requests
import json
from dateutil.parser import parse
import datetime
import time

def sumUpResponse(inquiryInfo, error_message, res_dictionary):
    reptileDict = {}
    reptileDict['id'] = inquiryInfo['id']
    reptileDict['inquiryId'] = inquiryInfo['inquiryId']
    reptileDict['isRenewal'] = 0  # 没有续保情况时候默认为0
    reptileDict['cityName'] = '四川'  # 没有筛选情况下默认为四川
    if 'commercialInsuransVo' in res_dictionary['quotesInfo']:
        # 商业险
        commInfo = res_dictionary['quotesInfo']['commercialInsuransVo']
        # 折扣率信息
        reptileDict['manageCoefNum'] = commInfo['nonClaimDiscountRate']  # 无赔款折扣系数
        reptileDict['illegalCoefNum'] = commInfo['trafficTransgressRate']  # 交通违法系数
        reptileDict['selfChannelNum'] = commInfo['comm_channelRate']  # 自主渠道系数
        reptileDict['selfUnderNum'] = commInfo['comm_underwritingRate']  # 自主核保系数
        # 商业险详细
        reptileDict['insuranceCompanyNameOne'] = '太平洋保险'  # 商业险投保公司
        reptileDict['policyOneNo'] = commInfo['comm_insuranceQueryCode']  # 商业险保单号
        reptileDict['insuranceCompanyOneStartDate'] = commInfo['stStartDate']  # 商业险起始日期
        reptileDict['insuranceCompanyOneEndDate'] = commInfo['stEndDate']  # 商业险截止日期
        reptileDict['insurances'] = ''  # 商业险险种列表
        reptileDict['insurancePrice'] = commInfo['premium']  # 商业险保费

        # =====================================================车辆损失险
        if 'DAMAGELOSSCOVERAGE' in commInfo:
            reptileDict['chesuanInsuranceBaoe'] = res_dictionary['DamagePrice']  # 车辆损失保额
            reptileDict['chesuanInsurancePrice'] = commInfo['DAMAGELOSSCOVERAGE']['premium']  # 车辆损失险额
        else:
            reptileDict['chesuanInsuranceBaoe'] = 0  # 车辆损失保额
            reptileDict['chesuanInsurancePrice'] = 0  # 车辆损失险额
        # =====================================================第三者责任险额
        if 'THIRDPARTYLIABILITYCOVERAGE' in commInfo:
            reptileDict['disanfangInsurancePrice'] = commInfo['THIRDPARTYLIABILITYCOVERAGE']['premium']  # 第三者责任险额
        else:
            reptileDict['disanfangInsurancePrice'] = 0  # 第三者责任险额
        # =====================================================全车盗抢险额
        if 'THEFTCOVERAGE' in commInfo:
            reptileDict['chedaoInsurancePrice'] = commInfo['THEFTCOVERAGE']['premium']  # 全车盗抢险额
        else:
            reptileDict['chedaoInsurancePrice'] = 0  # 第三者责任险额
            # =====================================================司机座位责任险额
        if 'INCARDRIVERLIABILITYCOVERAGE' in commInfo:
            reptileDict['sijiInsurancePrice'] = commInfo['INCARDRIVERLIABILITYCOVERAGE']['premium']  # 司机座位责任险额
        else:
            reptileDict['sijiInsurancePrice'] = 0  # 司机座位责任险额
            # =====================================================乘客座位责任险
        if 'INCARPASSENGERLIABILITYCOVERAGE' in commInfo:
            reptileDict['chenkeInsurancePrice'] = commInfo['INCARPASSENGERLIABILITYCOVERAGE']['premium']  # 乘客座位责任险(4座)额
        else:
            reptileDict['chenkeInsurancePrice'] = 0
            # =====================================================玻璃单独破碎险额
        if 'GLASSBROKENCOVERAGE' in commInfo:
            reptileDict['boliInsurancePrice'] = commInfo['GLASSBROKENCOVERAGE']['premium']  # 玻璃单独破碎险额
        else:
            reptileDict['boliInsurancePrice'] = 0
            # =====================================================车身划痕损失险额
        if 'CARBODYPAINTCOVERAGE' in commInfo:
            reptileDict['huahenInsurancePrice'] = commInfo['CARBODYPAINTCOVERAGE']['premium']  # 车身划痕损失险额
        else:
            reptileDict['huahenInsurancePrice'] = 0
            # =====================================================自燃损失险额
        if 'SELFIGNITECOVERAGE' in commInfo:
            reptileDict['ziranInsurancePrice'] = commInfo['SELFIGNITECOVERAGE']['premium']  # 自燃损失险额
        else:
            reptileDict['ziranInsurancePrice'] = 0
            # =====================================================发动机涉水损失险额
        if 'PADDLEDAMAGECOVERAGE' in commInfo:
            reptileDict['fadongjiInsurancePrice'] = commInfo['PADDLEDAMAGECOVERAGE']['premium']  # 发动机涉水损失险额
        else:
            reptileDict['fadongjiInsurancePrice'] = 0
            # =====================================================指定专修厂特约条款额
        if 'APPOINTEDREPAIRFACTORYSPECIALCLAUSE' in commInfo:
            reptileDict['zhuanxiuInsurancePrice'] = commInfo['APPOINTEDREPAIRFACTORYSPECIALCLAUSE']['premium']  # 指定专修厂特约条款额
        else:
            reptileDict['zhuanxiuInsurancePrice'] = 0
            # =====================================================无法找到第三方特约险额
        if 'DAMAGELOSSCANNOTFINDTHIRDSPECIALCOVERAGE' in commInfo:
            reptileDict['teyueInsurancePrice'] = commInfo['DAMAGELOSSCANNOTFINDTHIRDSPECIALCOVERAGE'][
                'premium']  # 无法找到第三方特约险额
        else:
            reptileDict['teyueInsurancePrice'] = 0
    if 'compulsoryInsuransVo' in res_dictionary['quotesInfo']:
        # 交强险详细
        compInfo = res_dictionary['quotesInfo']['compulsoryInsuransVo']
        reptileDict['insuranceCompanyNametwo'] = '太平洋保险'  # 交强险投保公司
        reptileDict['policyNo'] = compInfo['comp_insuranceQueryCode']  # 交强险保单号
        reptileDict['quotesPricetwo'] = compInfo['comp_totalPremium']  # 强制险出单费
        reptileDict['insuranceCompanyTwoStartDate'] = parse('2018-01-01')  # 交强险起始日期
        reptileDict['insuranceCompanyTwoEndDate'] = parse('2018-12-31')  # 交强险截止日期
        reptileDict['jiaoqiangInsurancePrice'] = compInfo['comp_standardPremium']  # 交强险额
        reptileDict['chechuanInsurancePrice'] = compInfo['comp_taxAmount']  # 车船税额
        # 不计免赔信息
        reptileDict['bujimianpeiName'] = res_dictionary['nonDeductible']['name']  # 不计免赔险名
        reptileDict['bujimianpeiPrice'] = res_dictionary['nonDeductible']['value']  # 不计免赔保费
    if 'carInfo' in res_dictionary['quotesInfo']:
        # 车信息
        carInfo = res_dictionary['quotesInfo']['carInfo']
        reptileDict['vin'] = carInfo['carVIN']  # 车架号
        reptileDict['motorNum'] = carInfo['engineNo']  # 发动机号
        reptileDict['labeltype'] = carInfo['factoryType']  # 厂牌型号
        reptileDict['initialDate'] = carInfo['stRegisterDate']  # 初登日期
        reptileDict['ownerContact'] = 1383838438#carInfo['phoneNo']  # 车主手机号码
        reptileDict['licenseNumber'] = carInfo['plateNo']  # 车牌号
        reptileDict['ownerName'] = carInfo['ownerName']  # 车主姓名
        reptileDict['idCard'] = carInfo['certNo']  # 证件号码
        reptileDict['carTypeCode'] = '02'#carInfo['plateColor']  # 号牌种类
        reptileDict['approvedLoadQuality'] = carInfo['emptyWeight']  # 核定载质量
        reptileDict['operation'] = 0  # 使用性质 0非营运 1营运  #=======================预留
        reptileDict['households'] = 0  # 是否过户  #=======================预留
    # 表单信息
    reptileDict['insuranceCompanyId'] = res_dictionary['codeNo']  # 保单号
    reptileDict['quotesPrice'] = res_dictionary['sumPrice']  # 保费

    reptileDict['state'] = 1  # 1成功；2失败；3等待
    reptileDict['createTime'] = datetime.datetime.now()  # 创建时间
    reptileDict['updateTime'] = datetime.datetime.now()  # 修改时间
    reptileDict['message'] = error_message  # 爬虫信息
    reptileDict['rate'] = res_dictionary['quotesInfo']['commercialInsuransVo']['comm_premiumRatio']  # 折扣率

    reptileDict['company'] = '太平洋保险'  # 保险公司
    reptileDict['companyEndDate'] = parse(res_dictionary['quotesInfo']['commercialInsuransVo']['stEndDate'])  # 保险到期日
    return reptileDict
def ModelQuery(vincode):
    ModelQueryheaders={'Accept':'application/json, text/plain, */*',
'Accept-Encoding':'gzip, deflate, br',
'Accept-Language':'zh-CN,zh;q=0.8',
'Connection':'keep-alive',
'Content-Length':'85',
'Content-Type':'application/json;charset=UTF-8',
'Cookie':'WT-FPC=id=2201b2f48dc52a009651519713429025:lv=1519713443108:ss=1519713429025:fs=1519713429025:pn=6:vn=1; BSFIT_OkLJUJ=NF1Y5QY94RH75AIP; BSFIT_KaLeL=a597a29bfc4f3bb7af61ed9799df3331; BIGipServerICORE-PNBS_DMZ_PrdPool=3542424748.42357.0000; CAS_SSO_COOKIE=9e90f8465e5298ac015e7041fa150006-361d5015a5274854840e06acc04c9049; JSESSIONID=WIi-Gv6HvwSh8YW7wJt9SIPhMtWpIZrwRT1PLyqIq583OVB1kqu5!1892159151; _WL_AUTHCOOKIE_JSESSIONID=-D2WyVfi2GrVpnKeSZK2',
'Host':'icorepnbs.pingan.com.cn',
'Origin':'https://icorepnbs.pingan.com.cn',
'Referer':'https://icorepnbs.pingan.com.cn/icore_pnbs/mainCtrl.tpl?applicantPersonFlag=1&familyPrd=&bsDetailCode=2-3-9-M&usageAttributeCode=02&ownershipAttributeCode=03&insuranceType=1&agentSalerName=&businessCertificateNum=&empBusinessCertificateNum=&deptCodeText=2269505&secondLevelDepartmentCode=226&deptCode=2269505&employeeCodeText=2261025001&employeeCode=2261025001&channelCode=9&agentCode=26950127&productCombineList=&partnerWorknetPanel=&worknetCode=&conferVal=2695012716001+1&agentNameLike=&agentCodeText=&brokerCode=&agentName=%E5%9B%9B%E5%B7%9D%E8%81%9A%E4%BB%81%E4%BF%9D%E9%99%A9%E4%BB%A3%E7%90%86%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8%E9%AB%98%E6%96%B0%E5%88%86%E5%85%AC%E5%8F%B8&conferNo=2695012716001&subConferNo=1&dealerCode=&autoInsurance=true&propertyInsurance=false&accidentInsurance=false&rateClassFlag=14&employeeName=%E6%9D%A8%E5%B2%9A&saleGroupCode=22695050504&trafficProductCode=MP01000002&commercialProductCode=MP01000001&businessMode=undefined&systemId=ICORE-PTS&applyApproach=',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36'}
    data={"vehicleFrameNo":vincode,"departmentCode":"2269505","insuranceType":"1"}
    url = r'https://icorepnbs.pingan.com.cn/icore_pnbs/do/app/quotation/autoModelCodeQuery'
    response = requests.post(url,json.dumps(data),headers=ModelQueryheaders)
    try:
        cars = response.json()
        #{'analogyCarPrice': 0.0,
        # 'analogyCarPriceIncludeTax': 0.0,
        # 'autoModelCode': 'KDD3082SHT',
        # 'autoModelName': '凯迪拉克SGM6480NAX1多用途乘用车',
        # 'autoSeriesId': 'KDAAO',
        # 'available': True,
        # 'brandName': '上汽通用汽车',
        # 'bus': True, 'displayPrice': 374900.0,
        # 'effectiveDate': '2017-05-17 17:09:22',
        # 'exhaustMeasure': 1.998,
        # 'firstSaleDate': '2017',
        # 'fuzzyQueryKey': 'KDD3082SHT,上汽通用汽车,凯迪拉克SGM6480NAX1多用途乘用车,凯迪拉克XT5 28T AT周年庆四驱豪华型',
        # 'hfName': '正常',
        # 'nonBus': False,
        # 'optionDisplay':
        # 'KDD3082SHT/凯迪拉克SGM6480NAX1多用途乘用车/上汽通用汽车/手自一体 周年庆四驱豪华型 国Ⅴ/374900.0/2017',
        # 'pa18AliasName': '凯迪拉克XT5 28T AT周年庆四驱豪华型',
        # 'powerType': '汽油',
        # 'powerTypeCode': 'D1',
        # 'purchasePrice': 374900.0,
        # 'purchasePriceIncludeTax': 406900.0,
        # 'remark': '手自一体 周年庆四驱豪华型 国Ⅴ',
        # 'seats': 5, 'tons': 0.0,
        # 'tradeMarkId': 'KDA',
        # 'vehicleTypeNew': 'A012'}
        document={}
        if cars['encodeDict']:
            document['result']='success'
            document['data']=cars['encodeDict'][0]
        else:
            document['result'] = 'error'
            content = '没有检索到该车架号，请重新输入'
            document['data'] = content
    except Exception as e:
        document['result'] = 'error'
        content = '未知错误，请联系管理员'
        document['data'] = content
    return document
if __name__ == '__main__':
    print(ModelQuery('LSGNB83L1HA096459'))